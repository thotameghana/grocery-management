
package com.project.model;

public enum ReportType {
    DAILY, WEEKLY, MONTHLY, PRODUCT, CUSTOMER
}
