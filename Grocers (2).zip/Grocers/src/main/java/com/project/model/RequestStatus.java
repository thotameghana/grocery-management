package com.project.model;

public enum RequestStatus {
    PENDING, APPROVED, REJECTED;
}