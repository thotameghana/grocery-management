package com.project.model;

public enum RequestType {
    ADD, UPDATE, DELETE;
}

